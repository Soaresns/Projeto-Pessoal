import "../style.css";

/* =======================
   SELETORES
======================= */
const menuBtns = document.querySelectorAll(".menu-btn");
const cards = document.querySelectorAll(".card"); // corrigido
const selectTema = document.getElementById('tema');
const selectFonte = document.getElementById('fonte');
const btnSalvar = document.getElementById('salvar');
const btnSair = document.getElementById('btnSair');

/* =======================
   MENSAGENS
======================= */
function mostrarMensagem(texto, cor = "green") {
  let msg = document.getElementById("mensagem");

  if (!msg) {
    msg = document.createElement("p");
    msg.id = "mensagem";
    msg.style.textAlign = "center";
    document.body.prepend(msg);
  }

  msg.textContent = texto;
  msg.style.color = cor;
  msg.style.fontWeight = "bold";
  msg.style.margin = "10px 0";
  msg.style.display = "block";

  setTimeout(() => (msg.style.display = "none"), 3000);
}

/* =======================
   TEMA E FONTE
======================= */
function aplicarTema(tema) {
  document.body.classList.toggle('dark', tema === 'escuro');
  localStorage.setItem('tema', tema);
}

function aplicarFonte(fonte) {
  const mapFont = { pequeno: 'pequena', medio: 'media', grande: 'grande' };
  document.body.classList.remove('fonte-pequena', 'fonte-media', 'fonte-grande');
  document.body.classList.add(`fonte-${mapFont[fonte]}`);
  localStorage.setItem('fonte', fonte);
}

// Carregar preferências salvas
const temaSalvo = localStorage.getItem('tema') || 'claro';
const fonteSalva = localStorage.getItem('fonte') || 'medio';
aplicarTema(temaSalvo);
aplicarFonte(fonteSalva);
selectTema.value = temaSalvo;
selectFonte.value = fonteSalva;

// Aplicar mudanças em tempo real
selectTema.addEventListener('change', () => aplicarTema(selectTema.value));
selectFonte.addEventListener('change', () => aplicarFonte(selectFonte.value));

/* =======================
   MENU LATERAL
======================= */
menuBtns.forEach(btn => {
  btn.addEventListener("click", () => {
    menuBtns.forEach(b => b.classList.remove("active"));
    cards.forEach(c => c.classList.remove("ativa"));

    btn.classList.add("active");
    document.getElementById(btn.dataset.section).classList.add("ativa");
  });
});

/* =======================
   HORA DINÂMICA
======================= */
function atualizarUltimaAtualizacao() {
  const agora = new Date();
  const label = document.getElementById('ultimaAtualizacao');
  if (label) {
    label.innerText = `Última atualização: ${agora.toLocaleTimeString("pt-BR")}`;
  }
}
setInterval(atualizarUltimaAtualizacao, 1000);

/* =======================
   NOME E AVATAR
======================= */
function atualizarNomePerfil(nomeCompleto) {
  const nomePerfil = document.getElementById('nomePerfil');
  const avatar = document.getElementById('avatar');
  if (!nomePerfil || !avatar) return;

  nomePerfil.innerText = nomeCompleto;
  const partes = nomeCompleto.trim().split(' ');
  const iniciais = partes.length > 1
    ? partes[0][0] + partes[partes.length - 1][0]
    : partes[0][0];

  avatar.innerText = iniciais.toUpperCase();

  // pequena animação
  avatar.style.transform = "scale(1.2)";
  setTimeout(() => (avatar.style.transform = "scale(1)"), 300);
}

/* =======================
   BOTÃO SAIR
======================= */
btnSair.addEventListener("click", () => {
  if (confirm("Deseja realmente sair da conta?")) {
    window.location.href = "login.html";
  }
});

/* =======================
   SALVAR PERFIL
======================= */
btnSalvar.addEventListener('click', () => {
  const perfil = {
    nome: document.getElementById('nome').value,
    sobrenome: document.getElementById('sobrenome').value,
    email: document.getElementById('email').value,
    telefone: document.getElementById('telefone').value,
    departamento: document.getElementById('departamento').value,
    tema: selectTema.value,
    fonte: selectFonte.value,
    senha: document.getElementById('senha').value,
    notificacoes: document.getElementById('notificacoes').value,
    emailRecuperacao: document.getElementById('emailRecuperacao').value
  };

  console.log('Perfil atualizado:', perfil);

  // Atualiza nome e avatar
  atualizarNomePerfil(`${perfil.nome} ${perfil.sobrenome}`);

  // Salva no localStorage (opcional)
  localStorage.setItem('perfil', JSON.stringify(perfil));

  // Mensagem de sucesso
  mostrarMensagem("✅ Perfil salvo com sucesso!", "green");
});
// Carrega dados do perfil salvo (se houver)
window.addEventListener("load", () => {
  const perfilSalvo = JSON.parse(localStorage.getItem("perfil"));
  if (perfilSalvo) {
    document.getElementById('nome').value = perfilSalvo.nome;
    document.getElementById('sobrenome').value = perfilSalvo.sobrenome;
    document.getElementById('email').value = perfilSalvo.email;
    document.getElementById('telefone').value = perfilSalvo.telefone;
    document.getElementById('departamento').value = perfilSalvo.departamento;
    document.getElementById('senha').value = perfilSalvo.senha;
    document.getElementById('emailRecuperacao').value = perfilSalvo.emailRecuperacao;
    document.getElementById('notificacoes').value = perfilSalvo.notificacoes;
    atualizarNomePerfil(`${perfilSalvo.nome} ${perfilSalvo.sobrenome}`);
  }
})

